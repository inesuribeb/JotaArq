/**
 * architecture-page router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::architecture-page.architecture-page');
