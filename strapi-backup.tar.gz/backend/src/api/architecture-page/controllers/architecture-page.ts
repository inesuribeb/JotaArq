/**
 * architecture-page controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::architecture-page.architecture-page');
