/**
 * architecture-page service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::architecture-page.architecture-page');
